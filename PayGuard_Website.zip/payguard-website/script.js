/* PayGuard — interactions */

document.addEventListener("DOMContentLoaded", () => {
  // ----- Stars in hero -----
  const starsEl = document.getElementById("stars");
  if (starsEl) {
    const colors = ["#00E5C7", "#FF6B6B", "#FFC857"];
    for (let i = 0; i < 80; i++) {
      const star = document.createElement("div");
      star.className = "star";
      const size = 1.5 + Math.random() * 2.5;
      star.style.width = size + "px";
      star.style.height = size + "px";
      star.style.left = Math.random() * 100 + "%";
      star.style.top = Math.random() * 100 + "%";
      star.style.background = colors[Math.floor(Math.random() * colors.length)];
      star.style.opacity = 0.3 + Math.random() * 0.7;
      starsEl.appendChild(star);
    }
  }

  // ----- Mobile menu -----
  const nav = document.getElementById("nav");
  const menuToggle = document.getElementById("menuToggle");
  if (menuToggle && nav) {
    menuToggle.addEventListener("click", () => {
      nav.classList.toggle("open");
    });
    // Close on link click
    nav.querySelectorAll(".nav-links a").forEach((link) => {
      link.addEventListener("click", () => nav.classList.remove("open"));
    });
  }

  // ----- Smooth active nav highlight (simple) -----
  const sections = document.querySelectorAll("section[id], header[id]");
  const navLinks = document.querySelectorAll(".nav-links a");

  const observer = new IntersectionObserver(
    (entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute("id");
          navLinks.forEach((link) => {
            link.style.color = link.getAttribute("href") === "#" + id ? "var(--teal)" : "";
          });
        }
      });
    },
    { rootMargin: "-40% 0px -50% 0px", threshold: 0 }
  );

  sections.forEach((sec) => observer.observe(sec));
});
